import os
import pandas as pd

os.makedirs("data", exist_ok=True)

data = [
    ["Your account has been suspended. Click here to verify your identity http://scam-link.com", "phishing"],
    ["Meeting scheduled tomorrow at 10 AM, please join the Zoom link shared earlier.", "legit"],
    ["Congratulations! You won a $500 Amazon gift card. Claim now!", "phishing"],
    ["Project update: dataset has been uploaded to shared drive.", "legit"],
    ["Unusual login detected. Reset your password immediately http://unsafe-login.com", "phishing"],
    ["Reminder: submit your timesheet before Friday.", "legit"],
    ["Your bank account has been locked. Verify at http://fake-bank.com", "phishing"],
    ["Invoice attached for your review.", "legit"]
]

df = pd.DataFrame(data, columns=["text", "label"])
df.to_csv("data/emails_sample.csv", index=False, encoding="utf-8")
print("Created data/emails_sample.csv ({} rows)".format(len(df)))
