document.getElementById("detectBtn").addEventListener("click", async () => {
  const text = document.getElementById("emailText").value;
  if (!text) {
    document.getElementById("result").textContent = "Please paste an email.";
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    if (res.ok) {
      document.getElementById("result").textContent = `${data.label.toUpperCase()}${data.score ? " (score: " + data.score + ")" : ""}`;
    } else {
      document.getElementById("result").textContent = "Error: " + (data.error || res.statusText);
    }
  } catch (err) {
    document.getElementById("result").textContent = "Cannot reach API. Is it running?";
  }
});
