import requests

url = "http://localhost:5000/predict"
payload = {
    "text": "Your bank account has been locked. Verify immediately at http://fake-bank.com"
}

try:
    r = requests.post(url, json=payload, timeout=5)
    print("Status Code:", r.status_code)
    print("Response JSON:", r.json())
except Exception as e:
    print("Error:", e)
