import streamlit as st
from model_utils import PhishModel

st.set_page_config(page_title="PhishShield", layout="centered")
st.title("🛡 PhishShield — AI Phishing Email Detector")
st.write("Paste the email body below and click Detect.")

model = PhishModel()

email_text = st.text_area("Paste email text here:", height=240)

if st.button("Detect"):
    if not email_text.strip():
        st.warning("Please paste the email content to analyze.")
    else:
        res = model.predict(email_text)
        if res.get("error") == "model_not_trained":
            st.error("Model not trained. Run `python train_fallback.py` first.")
        else:
            label = res.get("label", "unknown").upper()
            score = res.get("score", None)
            if label.lower() == "phishing":
                st.error(f"⚠️ Result: {label}")
            else:
                st.success(f"✅ Result: {label}")
            if score is not None:
                st.write(f"Confidence: {score:.2f}")
