import re
import os
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

MODEL_PATH_DEFAULT = "models/tfidf_lr.joblib"

def clean_text(text: str) -> str:
    if not isinstance(text, str):
        text = str(text)
    text = text.lower()
    # replace urls with placeholder
    text = re.sub(r"http\S+|www\S+", " URL ", text)
    # remove non-alphanumeric (keep spaces)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    # collapse whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text

class PhishModel:
    """Wrapper around (model, vectorizer) saved with joblib."""
    def __init__(self, model_path: str = MODEL_PATH_DEFAULT):
        self.model_path = model_path
        self.model = None
        self.vectorizer = None
        self._load()

    def _load(self):
        if not os.path.exists(self.model_path):
            self.model, self.vectorizer = None, None
            return
        obj = joblib.load(self.model_path)
        if isinstance(obj, tuple) and len(obj) == 2:
            self.model, self.vectorizer = obj
        else:
            self.model = obj
            self.vectorizer = None

    def is_ready(self) -> bool:
        return (self.model is not None) and (self.vectorizer is not None)

    def predict(self, text: str):
        if not self.is_ready():
            return {"error": "model_not_trained"}
        cleaned = clean_text(text)
        X = self.vectorizer.transform([cleaned])
        label = self.model.predict(X)[0]
        result = {"label": label}
        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(X)[0]
            classes = list(self.model.classes_)
            prob_for_label = float(proba[list(classes).index(label)])
            result["score"] = round(prob_for_label, 4)
        return result

def train_fallback(csv_path: str = "data/emails_sample.csv", model_path: str = MODEL_PATH_DEFAULT):
    os.makedirs(os.path.dirname(model_path) or ".", exist_ok=True)
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"{csv_path} not found. Create data first.")
    df = pd.read_csv(csv_path)
    if "text" not in df.columns or "label" not in df.columns:
        raise ValueError("CSV must contain 'text' and 'label' columns.")
    df["text"] = df["text"].astype(str).apply(clean_text)
    vectorizer = TfidfVectorizer(max_features=20000, ngram_range=(1,2))
    X = vectorizer.fit_transform(df["text"])
    y = df["label"].astype(str)
    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)
    joblib.dump((model, vectorizer), model_path)
    print(f"Saved fallback model to {model_path}")
    return model_path
