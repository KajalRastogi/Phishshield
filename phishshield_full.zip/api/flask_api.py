from flask import Flask, request, jsonify
from flask_cors import CORS
from model_utils import PhishModel

app = Flask(__name__)
CORS(app)

model = PhishModel()

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "model_ready": model.is_ready()})

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or {}
    text = data.get("text") or data.get("email") or ""
    if not text:
        return jsonify({"error": "no_text_provided"}), 400
    res = model.predict(text)
    if res.get("error") == "model_not_trained":
        return jsonify({"error": "model_not_trained"}), 500
    return jsonify(res)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
