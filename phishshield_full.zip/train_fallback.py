from model_utils import train_fallback
import os

models_path = "models"
# If a file named 'models' exists, rename it to avoid conflicts
if os.path.exists(models_path) and not os.path.isdir(models_path):
    os.rename(models_path, models_path + "_backup")

os.makedirs(models_path, exist_ok=True)

if __name__ == "__main__":
    train_fallback()
